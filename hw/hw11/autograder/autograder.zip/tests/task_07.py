OK_FORMAT = True

test = {   'name': 'task_07',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> test_data = make_array(1, 2, 3, 4)\n>>> np.isclose(intercept(test_data, 2 * test_data), 0)\nTrue',
                                       'failure_message': '❌ intercept did not produce the correct result for our test data set.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ intercept produced the correct result for our test data set.'},
                                   {'code': '>>> np.isclose(intercept(make_array(1, -20, 1, 2), make_array(1, 20, 3, 4)), 3.7719298245614032)\nTrue', 'hidden': True, 'locked': False, 'points': 0.5},
                                   {'code': '>>> np.isclose(intercept(make_array(1, 2, 3, 4), make_array(-1, -2, -3, -4)), 0)\nTrue', 'hidden': True, 'locked': False, 'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

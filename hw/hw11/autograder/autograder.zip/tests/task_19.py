OK_FORMAT = True

test = {   'name': 'task_19',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(slope_null_value, (int, np.float32, np.float64))\nTrue',
                                       'failure_message': '❌ slope_null_value should be assigned to a number.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ slope_null_value is assigned to a number.'},
                                   {'code': '>>> slope_null_value == 0\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

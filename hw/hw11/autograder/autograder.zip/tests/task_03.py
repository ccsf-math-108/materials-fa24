OK_FORMAT = True

test = {   'name': 'task_03',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> np.isclose(correlation([1, 2, 3], [4, 5, 6]), 0.9999999999999999)\nTrue',
                                       'failure_message': '❌ correlation should show that linear data has a coefficient of 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ correlation shows that linear data has a coefficient of 1.'},
                                   {'code': '>>> np.isclose(correlation([-3, 0, 3], [-3, 0, 3]), 1.0000000000000002)\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

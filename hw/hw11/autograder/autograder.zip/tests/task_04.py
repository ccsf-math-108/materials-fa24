OK_FORMAT = True

test = {   'name': 'task_04',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> set(r_array).issubset({1, 2, 3, 4, 5})\nTrue',
                                       'failure_message': '❌ r_array should contain some of the integers 1, 2, 3, 4, or 5.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ r_array contains some of the integers 1, 2, 3, 4, or 5.'},
                                   {'code': '>>> set(r_array) == {1, 3, 4}\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

OK_FORMAT = True

test = {   'name': 'task_13',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> max_value_eur = np.max(fifa.column('value_eur'))\n"
                                               ">>> min_value_eur = np.min(fifa.column('value_eur'))\n"
                                               ">>> max_age = np.max(fifa.column('age'))\n"
                                               ">>> min_age = np.min(fifa.column('age'))\n"
                                               '>>> test_slope = (max_value_eur - min_value_eur) / (max_age - min_age)\n'
                                               '>>> test_intercept = 1.2 * 100000000.0\n'
                                               '>>> test_rmse = rmse(test_slope, test_intercept)\n'
                                               '>>> isinstance(test_rmse, (float, np.float32, np.float64))\n'
                                               'True',
                                       'failure_message': '❌ rmse should return a float.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ rmse returns a float.'},
                                   {   'code': ">>> max_value_eur = np.max(fifa.column('value_eur'))\n"
                                               ">>> min_value_eur = np.min(fifa.column('value_eur'))\n"
                                               ">>> max_age = np.max(fifa.column('age'))\n"
                                               ">>> min_age = np.min(fifa.column('age'))\n"
                                               '>>> test_slope = (max_value_eur - min_value_eur) / (max_age - min_age)\n'
                                               '>>> test_intercept = 1.2 * 100000000.0\n'
                                               '>>> np.isclose(rmse(test_slope, test_intercept), 346627863.32058465)\n'
                                               'True',
                                       'failure_message': '❌ rmse does not seem to work on our test data.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ rmse seems to work on our test data.'},
                                   {   'code': ">>> fit_slope = slope(fifa.column('age'), fifa.column('value_eur'))\n"
                                               ">>> fit_intercept = intercept(fifa.column('age'), fifa.column('value_eur'))\n"
                                               '>>> np.isclose(rmse(fit_slope, fit_intercept), 23095130.84371943)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

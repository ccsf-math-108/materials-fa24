OK_FORMAT = True

test = {   'name': 'task_17',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> set(birds.labels) == {'Egg Length', 'Egg Breadth', 'Egg Weight', 'Bird Weight', 'Predicted Bird Weight', 'Residual'}\nTrue",
                                       'failure_message': '❌ The birds table does not have the correct labels.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ The birds table has the correct labels.'},
                                   {   'code': '>>> np.isclose(np.sum(predicted_bird_weights), 270.4000000000001)\nTrue',
                                       'failure_message': "❌ The sum of your predicted bird weights doesn't seem correct.",
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ The sum of your predicted bird weights seems correct.'},
                                   {   'code': '>>> np.isclose(np.average(residuals), 0)\nTrue',
                                       'failure_message': '❌ The average residual calculated from your array residuals should be (approximately) 0.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ The average residual calculated from your array residuals is (approximately) 0.'},
                                   {   'code': ">>> np.isclose(correlation(birds, 'Egg Weight', 'Residual'), 0)\nTrue",
                                       'failure_message': '❌ The correlation between the egg weights and residuals calculated from your birds table should be (approximately) 0.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ The correlation between the egg weights and residuals calculated from your birds table is (approximately) 0.'},
                                   {   'code': ">>> birds.sort('Residual')\n"
                                               'Egg Length | Egg Breadth | Egg Weight | Bird Weight | Predicted Bird Weight | Residual\n'
                                               '32.14      | 22.87       | 8.9        | 5.8         | 6.33651               | -0.536514\n'
                                               '31.18      | 22.92       | 8.6        | 5.6         | 6.12096               | -0.52096\n'
                                               '31.14      | 23.7        | 8.9        | 6           | 6.33651               | -0.336514\n'
                                               '30.54      | 23.31       | 9          | 6.1         | 6.40837               | -0.308366\n'
                                               '32.72      | 23.25       | 9.2        | 6.3         | 6.55207               | -0.252069\n'
                                               '30.34      | 22.84       | 8.5        | 5.8         | 6.04911               | -0.249108\n'
                                               '32.16      | 23.34       | 9.2        | 6.4         | 6.55207               | -0.152069\n'
                                               '32.78      | 23.23       | 9.2        | 6.4         | 6.55207               | -0.152069\n'
                                               '31.56      | 22.54       | 8.5        | 5.9         | 6.04911               | -0.149108\n'
                                               '30.71      | 22.51       | 8.2        | 5.7         | 5.83355               | -0.133554\n'
                                               '... (34 rows omitted)',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

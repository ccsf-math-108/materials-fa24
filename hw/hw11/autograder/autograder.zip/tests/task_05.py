OK_FORMAT = True

test = {   'name': 'task_05',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> test_data = make_array(1, 2, 3, 4)\n>>> np.isclose(slope(test_data, 2 * test_data), 2)\nTrue',
                                       'failure_message': '❌ slope did not produce the correct result for our test data set.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': '✅ slope produced the correct result for our test data set.'},
                                   {'code': '>>> np.isclose(slope(make_array(1, -20, 1, 2), make_array(1, 20, 3, 4)), -0.8070175438596492)\nTrue', 'hidden': True, 'locked': False, 'points': 0.5},
                                   {'code': '>>> np.isclose(slope(make_array(1, 2, 3, 4), make_array(-1, -2, -3, -4)), -1)\nTrue', 'hidden': True, 'locked': False, 'points': 0.5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

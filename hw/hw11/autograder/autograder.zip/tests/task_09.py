OK_FORMAT = True

test = {   'name': 'task_09',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> test_data = make_array(1, 2, 3, 4)\n'
                                               ">>> test_tbl = Table().with_columns('x_col', test_data, 'y_col', 2 * test_data)\n"
                                               ">>> test_prediction = predict(test_tbl, 'x_col', 'y_col')\n"
                                               '>>> isinstance(test_prediction, np.ndarray)\n'
                                               'True',
                                       'failure_message': '❌ predict should return an array.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ predict returns an array.'},
                                   {   'code': '>>> test_data = make_array(1, 2, 3, 4)\n'
                                               ">>> test_tbl = Table().with_columns('x_col', test_data, 'y_col', 2 * test_data)\n"
                                               ">>> predict(test_tbl, 'x_col', 'y_col')\n"
                                               'array([ 2.,  4.,  6.,  8.])',
                                       'failure_message': '❌ predict seems to work correctly on the test data we used.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ predict seems to work correctly on the test data we used.'},
                                   {   'code': '>>> test_data = make_array(-2, -1, 1, 2)\n'
                                               ">>> test_tbl = Table().with_columns('x_col', test_data, 'y_col', test_data)\n"
                                               ">>> predict(test_tbl, 'x_col', 'y_col')\n"
                                               'array([-2., -1.,  1.,  2.])',
                                       'failure_message': '❌ predict seems to work correctly on the test data we used.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ predict seems to work correctly on the test data we used.'},
                                   {   'code': '>>> test_data = make_array(-2, -1, 1, 2)\n'
                                               ">>> test_tbl = Table().with_columns('x_col', test_data, 'y_col', -1 * test_data)\n"
                                               ">>> predict(test_tbl, 'x_col', 'y_col')\n"
                                               'array([ 2.,  1., -1., -2.])',
                                       'failure_message': '❌ predict seems to work correctly on the test data we used.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0.5,
                                       'success_message': '✅ predict seems to work correctly on the test data we used.'},
                                   {   'code': ">>> test_tbl = Table().with_columns('x_col', make_array(-20, -1, 11, 2), 'y_col', make_array(2, -100, 21, 22))\n"
                                               ">>> predict(test_tbl, 'x_col', 'y_col')\n"
                                               'array([-21.69117647, -13.30882353,  -8.01470588, -11.98529412])',
                                       'hidden': True,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
